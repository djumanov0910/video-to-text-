# Video → Matn

Video (yoki audio) ovozini matnga aylantiruvchi oddiy oynali dastur. [Whisper](https://github.com/SYSTRAN/faster-whisper) modeliga asoslangan.

## Imkoniyatlar

- Qo'llab-quvvatlanadigan tillar: **o'zbek, rus, ingliz, koreys, xitoy** (yoki avtomatik aniqlash)
- Maksimal fayl hajmi: **1 GB**
- Formatlar: mp4, mkv, avi, mov, webm, flv, wmv, m4v, mp3, wav, m4a
- Natijani `.txt` fayliga saqlash yoki nusxalash
- Ixtiyoriy vaqt belgilari: `[00:01:23 → 00:01:30]`
- Progress bar orqali jarayonni kuzatish

## O'rnatish

Python 3.8 yoki undan yangi versiya kerak.

```
pip install -r requirements.txt
```

yoki:

```
pip install faster-whisper
```

## Ishga tushirish

```
python video_to_text.py
```

## Foydalanish

1. **Tanlash...** tugmasi orqali video faylni tanlang.
2. Tilni va modelni tanlang.
3. **Matnga aylantirish** tugmasini bosing.
4. Tayyor matnni **Saqlash (.txt)** yoki **Nusxalash** orqali oling.

## Modellar haqida

| Model      | Tezlik     | Aniqlik   | Hajmi (taxminan) |
|------------|------------|-----------|------------------|
| `tiny`     | juda tez   | past      | 75 MB            |
| `base`     | tez        | past      | 150 MB           |
| `small`    | o'rtacha   | o'rtacha  | 500 MB           |
| `medium`   | sekinroq   | yaxshi    | 1.5 GB           |
| `large-v3` | sekin      | eng yaxshi| 3 GB             |

- Model birinchi marta tanlanganda internetdan avtomatik yuklab olinadi.
- **O'zbek tili** uchun kamida `medium`, yaxshisi `large-v3` tavsiya etiladi.
- NVIDIA videokartasi bo'lsa, dastur uni avtomatik ishlatadi, aks holda protsessorda ishlaydi.

## Eslatma

Uzun videolar ko'p operativ xotira va vaqt talab qilishi mumkin, ayniqsa protsessorda ishlaganda.
